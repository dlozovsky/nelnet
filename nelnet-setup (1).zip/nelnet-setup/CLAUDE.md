# CLAUDE.md

Repo for the two gate automations, both thin slices of AUTO-188: slice 1 is the weekly required-fields check, slice 2 is the biweekly structure check with team-lead notifier. Goal: both deployed (runs from a Nelnet laptop), in use by Eric's team, with a maintenance guide someone else can follow. If a change does not move one of them toward that, say so before doing it. Full plan: the gate plan and build plan in the Claude project, steps S0 to S15 and N1.

## Execution model
- An authorized user runs the Python app by hand from a Nelnet laptop. GitLab stores the code and runs the tests only. No pipeline run job, hosting, runner, or unattended service identity in the gate.
- US first, with the Jira instance as a setting in the settings file. NULSC (federal) is a second source entry added only after step N1 passes and Eric or the security owner authorizes it in writing. No NULSC data on the laptop, in Confluence, or in email before then.
- Confluence target is a setting (`dc` or `cloud`). Build and use the Data Center client first. The Cloud client comes before the Q1 2027 move.

## Language and dependencies
Python 3.13 preferred. Standard library only for the app. Settings are TOML read with `tomllib`. pytest is the only test dependency. Do not add a dependency, language, or runtime without asking. [TBD: Auto 3, can pip install pytest?]

## Build pattern
- Python does the deterministic steps: read, apply rules, publish, record the run, notify. The gate slices make no model call.
- The entry point takes a period ticket key: `py -3.13 -m adherence.run --report <id> --ticket KEY [--dry-run] [--rerun] [--resume]`. A dry run posts nothing. No polling.
- Each source system is read through one module (Jira in `jira_source.py`, Confluence in `confluence.py`) so a migration changes one module.
- Rules, the team-to-lead list, and the fix text live in the TOML settings file a business owner can read and change, not in code.
- No person fields in the data model. Assignee and reporter are never loaded. Only the notifier reads a separate contacts object.
- A check that cannot be computed reports `unavailable` and names the missing input. Never zero. A search that completes with zero issues is a valid zero.
- Run states STARTED, PUBLISHED, COMPLETED, FAILED are recorded as ticket comments. After COMPLETED a new run needs `--rerun`. After FAILED or a stuck run, `--resume` repeats the failed step. Sends are tracked in a separate sent-messages record (one comment per send, keyed by report, instance, period, opaque recipient id). Skip any key already recorded. Never write the recipient address.
- Nothing is written to disk by a run. The run log is the ticket comments.

## Layout (adjust to the real repo)
`adherence/` with `models.py`, `settings.py`, `rules.py`, `check.py`, `jira_source.py`, `render.py`, `confluence.py`, `run_record.py`, `run.py`, `notifier.py`; `tests/`; `settings.example.toml`; `.gitlab-ci.yml` (tests only); `README.md` (short, links to the Confluence maintenance guide).

## Commands
[TBD: fill in once the repo exists. Expected: `py -3.13 -m pytest`, then the run commands above.]

## Pass/fail criteria (write the test before the code)
- Slice 1: count per team equals a manual run of the same saved filter the same day. A failed source shows unavailable, not zero. A clean week creates no new ticket.
- Slice 2: every finding lands in exactly one lead's message or the unknown-lead message, and message totals equal the finding count. A lead with no findings gets nothing. A dry run sends nothing. A failed send is recorded and queued, never dropped. A retry skips recorded sends.
- Both: no personal names on a published page, no log files on disk, no credentials in code or comments, and a test scans every ticket comment for addresses, tokens, and names.
- Both: someone else can change the rules file or lead list and rerun using only the maintenance guide.
- The whole suite passes with real network blocked. Run tests before saying work is done and report failures as they are.

## Data and secrets
- Fixtures, tests, and docs use invented or sanitized data only unless the data rule is confirmed. [TBD: Dave 6 and Eric, approved tools and data]
- Never hard-code or print tokens. On a laptop they come from environment variables taken from the store the automation team approves. [TBD: Auto 1]
- No FedRAMP-boundary, CUI, or borrower data anywhere in this repo. Published pages carry team-level figures and issue keys only, with an allowlist of fields.
- Unanswered decisions escalate to Eric. They never become default build rules. If a step needs a value that is marked TBD, stop and ask.

## Style
- Match the surrounding code: naming, comment density, idiom.
- Short functions, plain names, type hints on public functions. Comments explain why, not what.
- Docs and commit messages: plain language, no em dashes, no filler words.

## Handoff
The maintenance guide is a Confluence Data Center page. It covers how to run by hand, where credentials live (never the values), how to change a rule or lead, common failures, how to reconcile an uncertain send before retrying, and how to turn it off. Maintainer: the author first, then Eric's team including Dave. Update the guide in the same change as the code.
