# Gate Brief

**Last updated:** 2026-10-28

## Role
- Senior AI Enablement and Automation Consultant, Nelnet Shared Services
- Start: October 27, 2026 (day one is security training)
- Fully remote. Core hours 10 a.m. to 3 p.m. Central.
- Work: discovery, enablement, and hands-on delivery, ending in handoff to internal teams

## Stakeholders
| Name | Role | What they care about |
|---|---|---|
| Eric Ritchie | Direct manager, owns the gate | Two automations working after the first month; work shipped throughout; systems that are safe, secure, and that his team understands and can support after handoff |
| Dave | Mentor and day-to-day contact. Directed AUTO-188 as the first work item | How-things-work questions go to Dave. Gate scope and approvals stay with Eric |

## Working with Eric and Dave
- Teams for questions any time. Weekly status to Eric and Dave. Blockers escalate right away on Teams.
- No standups for now. Eric leans toward scrum sprints with himself as main planning contact. [TBD: confirm]
- Weekly 1:1: the brief says yes, one transcript seemed to say no. [TBD: confirm with Eric]
- How AUTO-188 is structured in Jira is my call for now.
- Disagree and commit. All work is done personally.
- Jira notifications still go to a personal email. [TBD: Dave to switch to the Nelnet address]

## Teams served
Technical writing, IT training, and process. About 30 people, all under Eric.

## The gate
At week four: two automations deployed, in use by a team, with maintenance documentation someone else can follow. Automations do not need to be large. The point is proof of delivery.

**Clock start:** the four weeks start on the date Eric emails after security training is done. Keep that email as the record. Rebaseline every date in the plan when it arrives (called T0).
**Holiday risk:** Thanksgiving is November 26. Target: both in use by November 20. Week 4 is buffer, not new scope.

## Gate pair (settled by Eric, 2026-10-27: option a)
1. AUTO-188 Phase 1, weekly required-fields check, cut to the minimum. Runs from a period ticket, publishes a Confluence page of team-level findings, logs the run as comments on the ticket, and builds the small harness slice 2 reuses.
2. AUTO-188 Phase 3, biweekly structure check plus team-lead notifier, using a team-to-lead list in the settings file.

AUTO-188 is a nine-phase program of about 242 engineer hours (the ticket's estimates, which assume Java and exclude waiting on access and experts). The two slices are about 64 hours, a floor not a promise. AUTO-56 is out of the gate. The tech-writer pipeline stays a fallback only if a slice is blocked and Eric agrees. After the gate: Phase 2 monthly defect report (next real run December 1), weekly risk report, AI summary, ticket polling, team map, metrics viewer, any admin UI, scheduling.

## Eric's definitions (written answers, 2026-10-27)
- **Deployed:** working off a Nelnet laptop. No hosting, runner, or unattended service identity is needed for the gate.
- **In use:** Eric's team uses the output (the page and the emails) while I run it. Functional. Negotiable for each phase. Eric sets the final bar. [TBD: Eric 2, evidence of use]
- **Maintainers:** me first, then Eric's team including Dave.
- **Federal scope:** nearly everything touches NULSC (the federal environment). Build US first. NULSC needs its own validation and access. [TBD: does a US-only first release qualify?]

## Execution model
- An authorized user manually runs the Python app from a Nelnet laptop. GitLab (the team's group) stores the code and runs the tests. Scheduling, runners, and service identities are a later phase.
- A laptop still holds a secret: a personal token in an environment variable needs an approved place to live. [TBD: automation team answer]
- Confluence target: the current reports are on Confluence Data Center; the move to Cloud is Q1 next year. The gate publishes to Data Center. The target is a setting (dc or cloud) and the Cloud client comes before the move. Dave is arranging a Cloud sandbox space for dev and testing only. [TBD: Dave, which space and parent page the real runs publish to]
- Claude API access exists on the enterprise plan. The gate slices need no model call, so the key is not on the gate path.
- Send-as for the team mailbox: Eric will submit it. Recommended to Eric: my own account now, a service account later.

## Constraints
- No FedRAMP-boundary, CUI, or borrower data. NULSC information is off limits on the laptop, Confluence, and email until Eric or the security owner confirms in writing what may be handled where.
- Jira is moving from Data Center to cloud. Keep the Jira read in one module so the migration changes one module. Confluence has the same split.
- Claude Enterprise plan. Nelnet's Claude offers Sonnet and Haiku (no Opus). Eric has had better results with Claude than Cowork.
- Claude Code Projects (redesigned) is not on Enterprise yet. Enterprise scheduled tasks and Routines are per-user, so unattended production runs need a team-owned host later.
- Nelnet data and code stay in Nelnet tools. Practice code written before the start is rewritten here, not copied in.

## History so far
- 2026-10-15 to 10-19: Planning and orientation call. Working picks then were the newsletter and a NIST completeness check, with the tech-writer pipeline as backup.
- 2026-10-19: Clock start rule confirmed. Target both in use by Nov 20.
- 2026-10-26: Python 3.13 found in the company software portal. Build language is Python.
- 2026-10-27: First call with Dave. AUTO-188 assigned to me. Scored against the rubric. Newsletter and NIST parked.
- 2026-10-27: Follow-up with Eric: code in the team GitLab group, Claude API exists, hosting meeting later. Eric's written answers set the pair, definitions, maintainers, and clock-start rule. Dave confirmed Confluence Data Center.
- 2026-10-27: Plan frozen: laptop-first, US-first, defaults become escalations, four run states plus a sent-messages record. From here it changes only for Eric's or Dave's answers or findings from real runs.
- 2026-10-28: Eric confirmed option (a). Still open: US-only acceptance, NULSC authorization, send-as, and the sent-messages limitation.
