# Automation Candidates

**Last updated:** 2026-10-28

**Status:** Pair settled by Eric on 2026-10-27: AUTO-188 Phase 1 weekly required-fields check and AUTO-188 Phase 3 structure check and notifier. AUTO-56 is out of the gate. Newsletter and NIST are parked. The tech-writer pipeline is a fallback only if a slice is blocked and Eric agrees.

## Evaluation rubric

Score each 1 (poor) to 5 (strong). A candidate that scores 1 on Data Access or Adoption cannot meet the gate, whatever else it scores.

| Criterion | 5 looks like | 1 looks like |
|---|---|---|
| **Value** | Saves many hours a month, visible to Eric | Saves little, nobody notices |
| **Effort** | Working v1 in days | Weeks of build |
| **Data access** | Access in hand or approved in week one | Blocked or unclear owner |
| **Risk** | Low error cost, easy human review | Errors reach outside parties |
| **Adoption** | A named person will use it weekly | No clear user |
| **Gate timing** | Can be in use before week four | Only runs outside the gate window |

**Gate timing note:** a candidate must be in use by November 20 to score well on timing.

## Scores (provisional, 2026-10-27)

| Candidate | Value | Effort | Data | Risk | Adoption | Timing | Total |
|---|---|---|---|---|---|---|---|
| Tech-writer pipeline (AUTO-56 full) | 3 | 3 | 3 | 4 | 4 | 4 | 21 (soft: target undefined) |
| AUTO-56 propose-stage slice, Velocity | 3 | 2 | 3 | 4 | 3 | 4 | 19 |
| AUTO-188 Phase 1 weekly required-fields | 3 | 2 | 3 | 4 | 3 | 3 | 18 |
| Monthly newsletter | 3 | 3 | 2 | 4 | 3 | 3 | 18 |
| NIST completeness slice | 4 | 4 | 2 | 3 | 3 | 2 | 18 |
| AUTO-188 Phase 3 structure check and notifier | 2 | 3 | 2 | 3 | 4 | 3 | 17 |
| AUTO-188 Phase 2 monthly defect report | 4 | 2 | 2 | 3 | 3 | 1 | 15 |

The scores are not why the pair was picked. Eric chose the pair. They stay here so a swap, if one is ever needed, can be argued from the same rubric.

Notes:
- Phase 1: about 52 hours a year saved. Effort 2 because 34 to 56 build hours sit behind a Phase 0 design. Weekly cadence gives several cycles before November 20.
- Phase 3: smallest saving (about 26 hours a year), so Value 2. Adoption 4 because a named expert and team leads already work this loop. Risk 3 because messages go to people. Sends may fall near November 4 and November 18, then December 2. That is a guess. [TBD: Expert 3, next send date]
- Phase 2: biggest saving but runs at the start of each month. Next real run is December 1, after the gate window.
- AUTO-56 slice: propose-stage only for Velocity, about 50 hours plus discovery logic. It shares no code with the AUTO-188 harness and needs a Claude API key, a labeled evaluation set, GitLab read access for an unattended identity, and a Jira administrator for proposal statuses.

## Pair

| Rank | Candidate | Why |
|---|---|---|
| 1 | AUTO-188 Phase 1 weekly required-fields check | Assigned work, weekly cadence gives at least two live cycles before Nov 20, builds the harness |
| 2 | AUTO-188 Phase 3 structure check and notifier | Reuses almost everything from slice 1, needs no model or API key, named expert and leads already work this loop |
| Fallback | Tech-writer pipeline (AUTO-56 slice) | Only if a slice is blocked and Eric agrees |
| Parked | Newsletter, NIST, Phase 2, AUTO-188 Phases 4 to 8 | After the gate |

**What would change this:** Eric wants the full Phase 0 first; Eric requires NULSC coverage for acceptance, or the laptop, the Confluence destination, or the email recipients are not authorized for NULSC information; the notifier cannot send from a shared address; the structure report's US scope turns out larger than assumed.

## Parked: monthly newsletter and NIST evidence intake
Notes from October 19 stay valid if either becomes a fallback. Newsletter: someone on Dave's team reviews closed tickets across two Jira instances and writes a monthly summary. NIST: about 600 evidence items in a 10-day window; completeness check only, rules in code, no model. [TBD: ask only if one returns]
