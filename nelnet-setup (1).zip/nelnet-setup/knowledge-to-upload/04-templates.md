# Templates

Four templates in one file. When I say WRITE, use the one I name. Mark unknowns as [TBD: question to ask].

---

## Template 1

# Requirements: [Automation Name]

**Version:** 0.1 · **Date:** · **Owner:** [my name] · **Business owner:** [TBD]

## 1. Problem
One or two sentences. What is slow, manual, or error-prone today?

## 2. Current process
| Step | Who | Tool | Time per cycle |
|---|---|---|---|
| | | | |

**Total today:** [hours per month]

## 3. Users
Who will use this, and how often?

## 4. Success metric
One number that shows it works. Example: monthly newsletter drafted in under 1 hour instead of 8.

## 5. Scope
**In (v1):**
-

**Out (v1):**
-

## 6. Inputs and outputs
| Input | Source | Access status |
|---|---|---|
| | | Have / Requested / Blocked |

**Output:** what is produced, in what format, delivered where.

## 7. Where AI is used
| Step | What the model does | Human review point |
|---|---|---|
| | | |

## 8. Risks
| Risk | Impact | Mitigation |
|---|---|---|
| | | |

## 9. Acceptance criteria
- [ ]
- [ ]

## 10. Open questions
- [TBD: ]

---

## Template 2

# Test Plan: [Automation Name]

**Version:** 0.1 · **Date:** · **Requirements version:**

Written before the build. If a criterion can't be tested, it isn't a criterion yet.

## 1. Pass/fail criteria
| Criterion | Pass means | How measured |
|---|---|---|
| | | |

## 2. Functional tests
| # | Scenario | Input | Expected result | Result |
|---|---|---|---|---|
| F1 | Normal case | | | |
| F2 | Empty input | | | |
| F3 | Source system unavailable | | | |
| F4 | Duplicate or malformed record | | | |

## 3. LLM evaluation set
Small and honest beats large and vague. Start with 10 to 20 cases, including the hard ones.

| # | Input (sanitized) | Expected output or property | Failure mode it checks | Pass? |
|---|---|---|---|---|
| E1 | | | Invented facts | |
| E2 | | | Missed required field | |
| E3 | | | Wrong source cited | |
| E4 | | | Should abstain but didn't | |

**Pass threshold:** [e.g. 18 of 20, with zero invented facts]

## 4. Human review check
- Who reviews output before it's used?
- What do they check?
- How long does review take?

## 5. Regression
What gets re-run after any prompt or code change?

## 6. Sign-off
| Name | Role | Date |
|---|---|---|
| | | |

---

## Template 3

# Maintenance Guide: [Automation Name]

Written for someone who has never seen this automation and has to keep it running without me.

**Owner after handoff:** [name] · **Last updated:** · **Version:**

## 1. What it does
Two or three sentences in plain language.

## 2. Where it runs
- Location (server, pipeline, scheduled job):
- Repository (GitLab path):
- Schedule or trigger:

## 3. How to run it manually
Step by step, copy-pasteable commands.

1.
2.

## 4. Dependencies and access
| Dependency | Purpose | Where credentials are stored (never the values) | Who grants access |
|---|---|---|---|
| | | | |

## 5. Configuration
| Setting | Location | What changing it does |
|---|---|---|
| | | |

## 6. Prompts
- Where prompts live:
- How to change a prompt safely: edit, run the evaluation set in the test plan, compare results, then deploy.

## 7. How to tell it's working
- Healthy output looks like:
- Where logs are:
- Alerts, if any:

## 8. Common failures
| Symptom | Likely cause | Fix |
|---|---|---|
| | | |

## 9. How to turn it off
Exact steps, and what manual process replaces it.

## 10. Contacts
| Name | Role | When to contact |
|---|---|---|
| | | |

## 11. Change log
| Date | Change | By |
|---|---|---|
| | | |

---

## Template 4

# Weekly Status: Week [N]

**Dates:** · **Gate week:** [N of 4, or "onboarding"]

## Gate progress
| Automation | Stage | In use by | Maintenance doc |
|---|---|---|---|
| 1. | Requirements / Building / Testing / Deployed / In use | [names, count] | Not started / Draft / Done |
| 2. | | | |

## Done this week
-

## Next week
-

## Blockers and asks
| Blocker | Who can unblock | Needed by |
|---|---|---|
| | | |

## Decisions made
-

## Risks to the gate
-

