# Gate Plan

**Last updated:** 2026-10-28. The plan is frozen except for Eric's or Dave's answers and findings from real runs. Open items and cutoffs are in file 08. Build steps S0 to S15 and N1 are in file 10. Labels (Eric 2, Dave 4, Expert 3) point to file 08.

**Execution model, everywhere in this plan:** an authorized user manually runs the Python app from a Nelnet laptop. GitLab stores the code and runs the tests. Scheduling, runners, and service identities are a later phase.

## The two slices

**Slice 1: Phase 1 weekly required-fields check (gate #1)**
- Short Phase 0 for the reports in scope: walk each through with its expert and write down the rules, the saved filter, who reads the results, and what people do on a failure.
- Smallest harness: a TOML settings file of rules, the Jira read in one module, a Confluence publisher (Data Center first, Cloud later), and the run recorded as comments on the period ticket.
- Entry point takes a period ticket key. A person starts it each period from their laptop. No polling, no pipeline.
- Parallel run: the expert checks results against their own run for the same week.

**Slice 2: Phase 3 biweekly structure check and notifier (gate #2)**
- A new check on the same harness: the rule over the Program, Initiative, Milestone, Epic, Story hierarchy.
- Publish findings to Confluence as team-level figures and issue keys, no personal names.
- The notifier sends one message per team lead from a team-to-lead list in the settings file. A finding with no known lead goes to the expert.
- Template baseline is today's email, three parts: why it matters, what to do with links to the report pages, and a deadline. Eric approves the template before anything sends automatically.
- First sends: dry run to me and the expert, then the expert approves, then real sends. Email in today's format; Teams comes after the gate.

**Cut for the gate:** monthly defect report, weekly risk report, AI summary, ticket polling, publication hold, full team map, metrics viewer, metric storage, retiring any Confluence page, any model call, any admin UI, any scheduling.
**Follow the ticket's design:** one message per team lead (not per person), and each report keeps its Confluence page.

## Draft pass/fail criteria (TEST mode, set before building)
- Slice 1: the count per team equals a manual run of the same saved filter on the same day.
- Slice 1: a source that fails shows as unavailable and names the missing input, never zero findings. A search that completes with zero issues is a valid zero.
- Slice 1: a clean week creates no new ticket, and the run is recorded as comments on the period ticket.
- Both: no personal names on a published page, no log files on disk, no credentials in code or comments.
- Slice 2: on a parallel run, the count per rule set equals the existing page's count for the same run.
- Slice 2: every finding in a frozen sample lands in exactly one lead's message or the unknown-lead message, and the total across messages equals the finding count.
- Slice 2: a lead with no findings receives nothing. A dry run sends nothing. A failed send is recorded and queued, never dropped. A retry skips messages already recorded as sent.
- Slice 2: the expert approves the dry-run drafts with no content edits. [TBD: Eric may set a different bar]
- Both: someone other than me can change the rules file or lead list and rerun using only the maintenance doc. Maintainer: me first, then Eric's team.

## Week by week
T0 is the date in Eric's clock-start email. Example dates assume T0 is Monday November 2: week 3 ends on the November 20 target and week 4 is Thanksgiving week. If T0 moves, shift every date. The one fixed calendar fact is the structure report's send cycle. If it still runs every two weeks from the September sample, sends fall near November 4 and November 18, then December 2, past the gate. [TBD: Expert 3]

**Before T0 (no access needed).** Step S0 first: confirm with Eric in writing that engineering work during onboarding is authorized. Then build with synthetic data only: repo, interfaces, fixtures, test infrastructure, plumbing (S1, S2, S6 to S11, generic rule mechanics in S3 to S5). Hold every real rule value, field name, and filter until the expert walk-through. Documentation: A1 to A5 and A7. Adoption: book the expert hour through Dave, send the automation team its questions, file every access request.

**Week 1 (T0 to T0 plus 4 days): slice 1 on real data.** Put the real rules, saved filter, and team field into the settings file after the expert walk-through (B1). S12 dry run on the US instance. S13 publish to a test parent page. Test: count per team equals a manual run the same day. Documentation: fill the maintenance doc with real values. Adoption: show the test page to the expert and agree where Eric's team looks for it. Slice 2 starts: walk the structure report through (B2), add the link and date rule types and the contacts object, draft the notifier template from today's email. If Eric requires NULSC for acceptance: run N1 now and hold both slices until authorization is confirmed in writing. Friday: weekly status.

**Week 2 (T0 plus 7 to 11): slice 1 live, slice 2 in dry run.** Publish to the real parent page and run weekly from the laptop. The expert checks it against their own run (S14). Slice 2: dry run on the US instance for the first available send, compared with the expert's manual list. Dry run goes to me and the expert only. Finish the slice 1 maintenance doc and run S15. Adoption: the team looks at the page instead of the manual run. Record who looked and when.

**Week 3 (T0 plus 14 to 18): the November 20 target week.** Slice 1: second live run, so at least two cycles. Slice 2: first real send, approved by the expert, with Eric having approved the template and the sent-messages limitation. If send-as is not granted, the expert sends our drafts and that is recorded. [TBD: does Eric count that as in use] Maintenance doc for slice 2, including how to reconcile an uncertain send before retrying: check the sent-messages record and the sending mailbox's sent items for that recipient and period, add the missing record or resend, then resume. Handoff check with Dave or another member of Eric's team. Ask Eric to confirm in writing that both are in use.

**Week 4 (Thanksgiving week): buffer, not new scope.** Fix what the first real sends showed. Run N1 (unless Eric moved it to week 1) if NULSC access is cleared and authorized, and add it as a second source entry only if it passes. Retrospective and next-phase plan. No new features.

## Acceptance evidence
Eric sets the final bar. A demonstration alone does not count. Each item goes on the Friday status.

| Slice | Evidence |
|---|---|
| Slice 1, weekly check | A successful real run on the real instance and parent page. Results match the existing manual process for the same period, with any difference explained. Confirmation from a team member that they used the published report. |
| Slice 2, structure notifier | Verified findings compared with the expert's manual list. An approved recipient mapping. A successful notification cycle with real sends, recorded on the ticket. Confirmation from the receiving team that they got and used the notification. |

## Day-one access requests (calendar time)
- SharePoint access to the report instructions folder
- Jira read, search, and comment access on the report projects, on my own account for the gate
- A Confluence Data Center space and parent page. A Cloud sandbox space for dev and testing. Service identities and tokens only for later unattended runs.
- Time with both experts
- A Jira administrator to review the period-ticket automation rules
- Read access to the team directory project
- Send-as on the team mailbox (Eric is submitting it), needed before slice 2 sends anything

## Phase 0 steps (shortened)
Estimate: 12 to 16 hours of planning and expert sessions against the ticket's 30 for the full Phase 0. That is a guess, not the ticket's number. A1 to A5 and A7 are planning. A6 is scaffolding.

**A. Start today, no new access needed**

| Step | Do | Pass or fail | Blocked by |
|---|---|---|---|
| A1 | In Nelnet's Claude, run the fact-sheet prompt on the ticket, its Phase 0 sub-task, and linked reference tickets | Table covers all four reports, uses roles not names, lists every UNKNOWN | Nothing |
| A2 | Open the current period tickets, today's Confluence page, and the sample email. Write a one-page note: ticket fields each check reads, page sections, the email's three parts | Note names each field the weekly check needs and where the saved filter lives, or marks it UNKNOWN | Expert 6 |
| A3 | Send the automation team questions, the Dave questions, and the access requests | Messages sent, dates logged | Nothing |
| A4 | Draft the settings-file design: one example rule per type (field filled, value in allowed list, field filled only when another holds, hierarchy link, date compare), plus team, lead, and "unavailable" handling | Example loads against a schema test with synthetic data; a failed source yields unavailable, never zero | Expert 1, 3, 4 for real rules; placeholders until then |
| A5 | Fill the test-plan template with the criteria above, each mapped to a named test with synthetic input and expected output | Every criterion has one test case with input and expected result written down | Eric 2 |
| A6 | Create the GitLab project in the team's group with the modules in file 10 and tests that make no real API calls | CI test job runs green on synthetic data | S0, permission to create a project |
| A7 | Start the maintenance doc on Confluence Data Center from the template, with a short README in GitLab that links to it | Sections exist for how to run, where the config is, how to change a team or lead, who to call | Eric 2 for the named maintainer |

**B. Needs the experts' time, no system access**

| Step | Do | Pass or fail | Blocked by |
|---|---|---|---|
| B1 | Walk the weekly required-fields check through with its expert (about an hour) | Every rule written as one of the A4 rule types and read back to the expert, who confirms. Exclusions, scope, reader, and failure handling written down | Dave 4, Expert 1, 3, 4, 5, 6 |
| B2 | Walk the structure report through: hierarchy rule, US scope, CAB approval field check, lead list, template wording | Rule written, five synthetic cases with expected outcomes confirmed by the expert, template wording approved by the expert | Expert 2, 4, 5, 7 to 11 |
| B3 | Write the short Phase 0 design note: harness shape, run start by ticket key, page layout, minimal metric record, notifier flow, what is cut | Eric accepts it in writing or by reply | Eric 2 |

**C. Waits on access** (build steps S12 to S15 and N1 in file 10 cover most of these)

| Step | Do | Pass or fail | Blocked by |
|---|---|---|---|
| C1 | Jira read through my own account on the US instance, with a completeness check | Count per team equals a manual run of the same saved filter the same day. A failed source reports unavailable and names the missing input | Auto 1, Dave 2 |
| C2 | Confluence publish helper, Data Center first | Page appears under the parent page with source, period, and time obtained, no personal names, and a re-run updates it without duplicating | Dave 2, Expert 12 |
| C3 | Run recording on the period ticket | Each step is a comment. A clean week creates no new ticket | Dave 2 |
| C4 | Manual laptop run from the ticket key | The laptop reaches Jira and Confluence, secrets are stored outside the code, a manual run works end to end | Auto 1 |
| C5 | Notifier dry run | Each finding lands in exactly one message, a lead with no findings gets nothing, nothing is sent | Expert 7, Dave 5 |
| C6 | Parallel run with the expert | Expert confirms results, or each difference has a recorded reason | B1, B2, C1 to C5, Expert 11 |
| C7 | First real send | Template approved by Eric first. One real send succeeds and a failed send is recorded and queued | Eric 8, Auto 2, send-as |
| C8 | Handoff check | Someone other than me changes a lead and reruns using only the maintenance doc. Maintainer named | Eric 2 |

**Order this week:** A1 and A3 today, S0 to Eric, then A2, A4, and A5 while waiting. Book the expert hour as soon as Dave makes the intro. Everything in C moves only when access lands, so those requests are the critical path.

## Flags to fix
1. Jira notifications go to a personal email. Until fixed, keep ticket comments free of anything confidential, because comments trigger emails.
2. Tools and data boundary: the call transcript came from a meeting-assistant app, and the ticket and sample email arrived as phone photos of a Nelnet screen. Confirm both are allowed (Dave 6). Read tickets inside Nelnet's Claude and bring back only sanitized fact sheets.
3. A laptop still holds a secret. The ticket's rule against personal credentials covers unattended runs only. Ask the automation team where a pilot token may live (Auto 1).
4. The published page's audience must be confirmed. Issue keys and links can reveal restricted work. [TBD: Dave 2, who can view the page]
5. The 242 hours assume Java and exclude waiting. Treat 64 hours for the two slices as a floor.
6. Weekly 1:1: confirm with Eric.

## Prompt: Step runner wrapper
Paste inside Nelnet's tools, one step at a time:
```
Step: <step id and the Do text>
Inputs: <what I am pasting>
Output: <the file or table the step must produce>
Check: <the pass or fail text for this step>

Do the step. Then answer PASS or FAIL against the check, list anything missing, and mark every guess as UNKNOWN. Do not invent facts about Nelnet systems or people. Use roles, not names.
```

## Prompt: Fact sheet (step A1)
Run inside Nelnet's approved Claude with the ticket description and sample email open there. Bring back only the output table.
```
I am preparing a sanitized fact sheet from a Jira ticket description and one sample email. Do not quote ticket or email text. Use roles, never personal names, and no email addresses or phone numbers.

For each of these four reports, give one row: weekly required-fields check, weekly risk report, biweekly structure report, monthly defect report.

Columns:
1. Cadence and usual run day
2. Who reads the results (role only)
3. Expert role
4. Jira instance(s) involved
5. Where the filter or query is defined (saved filter, query in a Confluence macro, SharePoint document, or UNKNOWN)
6. Number and type of rules (field filled, allowed list, conditional, hierarchy, age)
7. What is produced today (page, email, dashboard) and how many recipients per run
8. Hours per run today, if stated
9. Access, identities or permissions needed before building
10. Open questions that block building it

Write UNKNOWN for anything the sources do not state. After the table, list the day-one access requests with the owner role for each. Keep the whole answer under 400 words.
```
