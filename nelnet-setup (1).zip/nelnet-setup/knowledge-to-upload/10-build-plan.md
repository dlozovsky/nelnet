# Build Plan: Slice 1 Harness and Slice 2 Additions

**Last updated:** 2026-10-28. Use with the step runner wrapper in file 09, one step at a time, with synthetic inputs. Thin on purpose: no polling, no AI summary, no viewer, no metric storage. The run output carries the metric-record fields so a later phase can store them, but nothing stores them now. Follows the practice-kit pattern (Jira read in one module, rules in a settings file the expert can read, tests on synthetic data), rewritten inside Nelnet's GitLab, never copied.

## Design choices
- **Python 3.13 preferred, standard library only for the app.** Settings are TOML read with the built-in `tomllib` (Python 3.11 and up), so nothing depends on pip access. Tests use pytest only, run as `py -3.13 -m pytest`. The package sits at the repo root, so there is no install step. Pending a check of the Nelnet environment: the Python version, the `py` launcher, and whether pip can install pytest (Auto 3).
- **No person fields in the data model.** An issue carries its key, team, labels, and the fields the rules read. Assignee and reporter are never loaded, so the page cannot leak names. Slice 2 adds a separate contacts object that only the notifier reads.
- **A failed read is never zero.** A source that fails, or returns fewer issues than the total it reported, gives a team status of unavailable that names the missing input. A search that finishes cleanly with zero issues is a valid zero. Where the API gives no total, completeness rests on paging reaching its end.
- **Secrets** come from environment variables on the laptop, taken from the store the automation team approves for a pilot. Never from code or config. Service identities and masked CI variables belong to a later phase.
- **Nothing is written to disk by a run.** The run log is comments on the period ticket. Page output uses a strict allowlist of fields.
- **Confluence target is a setting** (`dc` or `cloud`). Build the Data Center client first.

## Repository layout (adjust to the real repo)
```
adherence/
  models.py           # Issue, TeamResult, RunResult
  settings.py         # load and validate the TOML
  rules.py            # rule types as pure functions
  check.py            # apply rules, group by team
  jira_source.py      # the only module that knows Jira
  render.py           # page body, allowlisted fields
  confluence.py       # publisher: interface, fake, DC client
  run_record.py       # run state and ticket comments
  run.py              # entry point
  notifier.py         # slice 2
settings.example.toml # synthetic
tests/
.gitlab-ci.yml        # runs tests only
README.md             # short, links to the Confluence maintenance doc
```

## Settings file (shape only, synthetic)
Real field names, filter, and teams come from the expert walk-through. Each TBD is a question that blocks a real value.
```toml
[source]
instance = "us"                 # one source entry per instance; NULSC is a second entry after N1
filter_id = "TBD"               # Expert 6
team_field = "TBD"
exclude_label = "TBD"

[publish]
target = "dc"                   # dc or cloud
parent_page_id = "TBD"          # Dave 2

[[rules]]
id = "r1"
type = "field_filled"           # also: value_in_list, field_filled_when
field = "TBD"
```
Slice 1 implements three rule types: `field_filled`, `value_in_list`, `field_filled_when`. The loader reserves `link_exists` and `date_compare` for slice 2 and rejects them with a clear message until they exist.

## Interfaces (shapes)
```python
class JiraSource(Protocol):
    def search(self, filter_id: str) -> SearchResult: ...    # raises SourceUnavailable
    def get_comments(self, ticket_key: str) -> list[str]: ...
    def add_comment(self, ticket_key: str, body: str) -> None: ...

class ConfluencePublisher(Protocol):
    def upsert_page(self, parent_id: str, title: str, body_html: str) -> str: ...
    # The title carries report, instance, and period. The same title updates the page,
    # a new title creates one. Returns the page id.

@dataclass
class TeamResult:            # mirrors the metric-record fields, nothing stores them
    team: str
    checked: int             # denominator
    failed: int              # numerator
    failed_keys_by_rule: dict[str, list[str]]
    status: str              # "ok" or "unavailable"
    missing_input: str | None

@dataclass
class RunResult:
    report_id: str
    instance: str
    period: str
    source: str
    obtained_at: datetime
    definition_version: str
    teams: list[TeamResult]
```
Entry point: `python -m adherence.run --report weekly_required_fields --ticket KEY [--dry-run] [--rerun] [--resume]`. A dry run prints the page body and posts nothing. Windows commands from the repository root (token variable names are placeholders until Auto 1 is answered):
```
set CONFLUENCE_TOKEN=
py -3.13 -m adherence.run --report weekly_required_fields --ticket KEY --dry-run
py -3.13 -m adherence.run --report weekly_required_fields --ticket KEY
```

## Run states and the sent-messages record
Each run writes its state as a comment on the period ticket: STARTED, PUBLISHED, COMPLETED, FAILED. FAILED can happen at any stage and records the step that failed. The latest state decides what happens next. After COMPLETED, a new run is refused unless `--rerun` is given. After FAILED, or a run stuck at STARTED or PUBLISHED, `--resume` repeats the failed step. Publishing is safe to repeat because it updates the page.

In slice 2, PUBLISHED means the report page is published, not that any email went out. Sending is tracked separately by a sent-messages record: one comment on the period ticket for each successful send, keyed by report, instance, period, and an opaque recipient id (never an address). Before every send the notifier reads that record and skips any key already there, including on a resume or a rerun. Duplicate delivery remains possible if the process stops between successful delivery and recording the result. Eric must approve this limitation before the first real send. The maintenance guide tells the operator to reconcile any uncertain send before retrying.

## Build steps (give Sonnet one at a time)
S1 to S11 need no access, only synthetic data. They are scaffolding and plumbing. The rule mechanics in S3 to S5 are generic, and every real rule value waits for the expert walk-through.

| Step | Do | Pass or fail | When |
|---|---|---|---|
| S0 | Confirm with Eric that building during onboarding, before the clock starts, is authorized | A written reply says yes, or says what is off limits | Today. Blocks every build step before the clock starts |
| S1 | Create the repo skeleton, a smoke test, and the CI file that runs the tests | pytest passes locally on the approved Python. CI test job is green once pushed | Now locally. Pushing needs permission in the team's GitLab group |
| S2 | Write models.py and settings.py: load the TOML and validate it | The example file loads. Five bad files each raise an error that names the problem: unknown rule type, missing field, duplicate rule id, empty allowed list, reserved slice 2 type | Now |
| S3 | Write rules.py with the three rule types as pure functions (generic mechanics only) | Truth-table tests pass for each type: a value present, empty string, whitespace only, missing, and not in the list. A conditional rule does not fire when its condition is false | Now |
| S4 | Write check.py: apply rules, skip the excluded label, group by team, count checked and failed | On the synthetic fixture the counts equal a checked-in expected JSON. Every issue is checked exactly once. Failed keys are a subset of checked keys. An issue with no team lands in Unassigned | Now |
| S5 | Add unavailable handling | A source that raises, or returns fewer issues than its reported total, gives status unavailable and names the missing input. A search that completes with a total of zero is a valid zero | Now |
| S6 | Write jira_source.py: the interface, a file-based fake, and an HTTP client that takes an injected opener, with paging and retry on rate limits | A canned two-page response returns every issue and the expected total. A rate-limit response is retried. A 401 raises SourceUnavailable and the message does not contain the token | Client code now. Real endpoint and auth wait on Auto 1 |
| S7 | Write render.py | The page body shows figures per team, issue keys per rule, source, period, time obtained, and definition version. A test fails if any field named like a person appears. Output is HTML-escaped and limited to an allowlist of fields | Now |
| S8 | Write confluence.py: the interface, a fake, and a Data Center client with an injected opener | First call creates a page, a second call with the same title updates it and returns the same page id. A missing parent id is refused. Pages for two instances with the same report and period get different titles and never overwrite each other | Client code now. Real space and token wait on Dave 2 |
| S9 | Write run_record.py | Comments carry the run state (STARTED, PUBLISHED, COMPLETED, FAILED, which names the failed step), one line per step, and a result line with counts only. A test scans every comment for email addresses, tokens, and names and finds none | Now |
| S10 | Write run.py and the entry point | A dry run makes zero write calls on the spies. A full run on fakes makes one page upsert and comments in order. After a simulated failure between STARTED and the page upsert, --resume finishes with exactly one page. A resumed run never repeats a send already recorded. After COMPLETED, a new run is refused without --rerun | Now |
| S11 | Block real network in tests and finish the CI file | The whole suite passes with socket.connect patched to raise. The CI file runs tests only | Now. The laptop is the only gate path |
| S12 | Dry run against the real US instance with the expert's saved filter | The count per team equals a manual run of the same saved filter on the same day | After Auto 1, Dave 2, Expert 6 |
| S13 | Publish to a test parent page, then the real one | The page matches the dry-run output, shows no names, and a re-run updates it rather than duplicating | After Dave 2, Expert 12 |
| S14 | Parallel run with the expert | The expert confirms the results, or each difference has a recorded reason | After B1, S12, Expert 11 |
| S15 | Fill the maintenance doc from the template | Someone other than me changes one rule's allowed list and reruns a dry run using only the doc | After S14. Maintainer named |
| N1 | Validate NULSC before counting it as covered: compare field identifiers, link semantics, API response shape, and authentication with US, and confirm who may view the published pages | A written compatibility list is complete. A dry run on NULSC gives counts equal to a manual run of the same saved filter. Any difference is mapped in that instance's source entry, never hidden | Week 1 if Eric requires NULSC for acceptance. Otherwise week 4, after access is cleared and Eric confirms it is permitted in writing |

Later phase, not the gate path: a mode that finds the latest period ticket without a start comment and runs it, so a scheduled pipeline can start the check with no person. Pass check: two schedule firings in one period produce one run.

## Maintenance doc outline
The guide is a Confluence Data Center page, because the team uses Confluence for docs. The repo holds only a short README that links to it.
1. What it does: one weekly check of required fields per team, published to Confluence and recorded on the period ticket.
2. Where it runs: the laptop setup and run command, plus the GitLab project path for the code. A pipeline is a later phase.
3. Run it manually: the exact Windows commands above, and the environment variables to set (names only, never values).
4. Dependencies and access: Jira access, Confluence access (personal accounts for the gate, service identities later), where each token is stored (never the value), and who grants each.
5. Configuration: the settings file, one row per section (source, publish, rules) and what changing it does.
6. Prompts: none, because slice 1 uses no model.
7. Healthy output and failures: a healthy page and run comment, plus a table seeded from the tests (source unavailable, unknown rule type, parent page missing, token expired).
8. Turn it off: stop running the command and say that the expert's manual check takes over.
9. Contacts and change log: the named maintainer, the expert, the Jira administrator.
Slice 2 adds how to reconcile an uncertain send.

## What slice 2 reuses
Almost everything: models, settings loader, check runner, the Jira source, the Confluence publisher, the run record, the entry point, the CI test file, and the secrets setup. New for slice 2 is small:
- two rule types, `link_exists` and `date_compare`, plus child-link fields on the issue;
- a contacts object (who to notify) that only the notifier reads;
- a notifier module with the message template, the lead list, a dry run, and a queue for failed sends;
- the send helper, which waits on send-as.
That matches the ticket's 16 to 24 hours for Phase 3 once the harness exists.

## Slice 2 rules from the current structure report (US)
The US page holds four rule sets, each a Jira query today. The hierarchy is Program, Initiative, Milestone, Epic, Story. Every rule fits a rule type already in the design: link exists, field filled, or date compare. (Source: a sanitized summary of the page. No staff names or ticket text.)

| Rule set | Applies to | Rule | Rule types |
|---|---|---|---|
| 1 Initiatives | In progress | At least one child milestone linked by parent link. Target start not in the future. Target end not blank and not in the past | Link exists, date compare, field filled |
| 2 Milestones | In progress | At least one child epic linked by parent link. Same date rules as initiatives | Link exists, date compare, field filled |
| 3 Epics | Teams that report under the program reporting process | Must have a parent link to a milestone | Link exists |
| 4 Stories | Same teams | Must have an epic link | Link exists |

An item carrying a not-applicable label is excluded from all four. The page gives fix instructions per rule, so the settings file holds that text and the notifier reuses it.

**Gaps to close with the expert:** who gets notified (Expert 7), one week or two (Expert 8), how the page finds the first linked child (Expert 9), which teams count as reporting teams (Expert 10), which recent run to compare against (Expert 11), where the pages live and who can view them (Expert 12).

**Extra test cases for slice 2 (synthetic data only):**
- An in-progress initiative with no child milestone is flagged. One with a start date in the future is flagged. One with a blank end date is flagged. One with an end date in the past is flagged. A compliant one is not.
- The same date and link cases hold for milestones.
- An epic with no parent milestone and a story with no epic are flagged.
- An item with the exclusion label is never flagged.
- On a parallel run, the count per rule set equals the page's count for the same run.

**Two design consequences:**
- The current page shows assignee and reporter names. The ticket forbids personal names on a page everyone can read, so the new page lists issue keys and team-level counts, and names appear only in the message to the notified person.
- The ticket notifies team leads from a team map. The page's own accountability is the initiative owner. If the expert says owners, the settings-file lead list becomes an owner mapping, and the unknown-lead rule matters more because many items are unassigned.
