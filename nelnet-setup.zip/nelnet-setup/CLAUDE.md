# CLAUDE.md

Repo for the two gate automations. Goal of this repo: two automations deployed, in use by a team, with maintenance documentation someone else can follow. If a change does not move one of them toward that, say so before doing it.

## Language
Python 3.13, installed from the company software portal. [TBD: confirm with Eric that the team that will own each automation can maintain Python.] Do not add a language or runtime that is not installed or in the company software portal. [TBD: Q29, can pip reach an approved package source? Until answered, keep dependencies to the minimum.]

## Build pattern
- Python does the deterministic steps: collect, filter, group, validate, write output.
- Claude is called only at a bounded judgment step, once, with a JSON schema for the output. Python validates the result and blocks anything that fails.
- No agent loops, no orchestration frameworks, no new dependencies without asking.
- A person reviews every output before it leaves the team.
- Source systems (Jira, SharePoint, evidence tracker) are read through one module each. A migration, such as Jira Data Center to cloud, must change one module only.
- Rules a business owner may need to change (for example completeness rules) live in a config file, not in code.

## Layout (adjust to the real repo)
- `newsletter/`: jira source, group, draft, check, run
- `nist/`: rules config, check, run
- `evals/`: evaluation cases (JSON) and runner
- `tests/`: unit tests
- `docs/`: requirements, test plan, maintenance guide per automation

## Commands
[TBD: fill in once the repo exists. Expected: install deps, run tests, run evals, run each automation.]

## Testing rules
- Pass/fail criteria are written before the code. Put them in the test plan first.
- Any LLM step has an evaluation set of 10 to 20 cases that includes the hard ones: invented facts, an instruction hidden in input, a reference to something not in the input, a case where the right answer is to abstain.
- Pass bar for LLM output: all cases pass and zero invented facts. Re-run the evals after any change to a prompt, model, rules file, or checker.
- Run tests and evals before saying work is done, and report failures as they are.

## Data and secrets
- Never put real data in tests, fixtures, evals, comments, commit messages, or logs unless the data rule is confirmed. [TBD: confirm with Eric]. Until then, fixtures are invented or sanitized.
- Never hard-code or print credentials, tokens, or keys. Read them from the approved secrets store or environment. [TBD: Q11, secrets approach]
- No FedRAMP-boundary, CUI, or borrower data anywhere in this repo.

## Style
- Match the surrounding code: naming, comment density, idiom.
- Short functions, plain names, type hints on public functions.
- Comments explain why, not what.
- Docs and commit messages: plain language, no em dashes, no filler words.

## Handoff
Each automation ships with a maintenance guide a stranger can follow: how to run it by hand, where it runs, where credentials live (never the values), how to change a prompt safely (edit, run evals, compare, deploy), common failures, how to turn it off. Update the guide in the same change as the code.
