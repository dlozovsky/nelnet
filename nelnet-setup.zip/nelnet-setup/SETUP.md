# Setting up Nelnet Claude (classic Projects)

Everything below was built from the files in this project. Nothing in the package contains Nelnet data. Three things need a quick check with Eric first; they are marked **Ask Eric**.

## What is in this folder

| Item | Where it goes |
|---|---|
| `custom-instructions.txt` | Paste into the project's custom instructions box |
| `knowledge-to-upload/` (5 files) | Upload as project knowledge |
| `CLAUDE.md` | Goes in the root of the repo you create in Nelnet's GitLab, for Claude Code |
| `SETUP.md` | This page. Do not upload. |

## Ask Eric before you start (one Teams message)

1. **Data rule.** May real Nelnet working data (ticket text, evidence items) go into Nelnet's Claude, or only sanitized samples? The instructions assume sanitized only until he answers. When he answers, edit the `[TBD: confirm with Eric]` block in the instructions and the matching line in `CLAUDE.md`.
2. **Uploading my own planning files.** The five knowledge files are mine (plans, templates, rubric). Confirm it is fine to upload them to the Nelnet project. This is Q26 in the open questions.
3. **Project visibility.** Keep the project private to you unless Eric wants it shared.

Suggested message: "Eric, before I put my planning notes into a Claude project on our Enterprise account: (1) can real working data go in there, or sanitized samples only? (2) OK to upload my planning files (gate brief, candidate rubric, templates)? I'll keep it private. Using sanitized only until you say otherwise."

## Steps: the Claude project

1. In Claude, open **Projects** and choose **Create project**. Name it "Gate Automations" (no need for a long name).
2. Set visibility to private if the option appears.
3. Open the project's **instructions** (labeled "Set project instructions" or "Custom instructions"). Paste the full text of `custom-instructions.txt`. Save.
4. Under **Project knowledge**, choose **Add content**, then upload the five files from `knowledge-to-upload/`. If the interface only takes text, paste each file as a text snippet with the file name as the title.
5. Smoke test, in a new chat inside the project. All three should pass:
   - "What is the gate and when does the clock start?" Expect: two automations, deployed, in use, documented; clock starts at full access plus security training; target November 20.
   - "EVALUATE: score the newsletter candidate." Expect it to fill the rubric where it can and mark the rest as `[TBD: ...]` rather than invent hours or names.
   - "Here is a ticket: [paste ticket text]." Expect it to stop you and apply the data rule. (Test this with a made-up line, not a real ticket.)
6. If anything fails, tell me which one and I will tighten the instructions.

## Keeping it current

Classic project files are read-only for Claude. The loop is:
1. Claude gives you a one-line decision log entry or answer.
2. You add it to your local copy of `03-decision-log.md` or `08-open-questions.md`.
3. In the project, remove the old file and upload the new one. Do this when you settle something, not every day.

Record sanitized answers only in file 08: counts, dates, field names, rules, yes or no.

## Steps: Claude Code

1. Create the repo in Nelnet's GitLab first. Rewrite the practice code there in Python 3.13 (from the company software portal). Do not copy the practice kit in. What carries over is the shape, the tests, and the evaluation cases.
2. Put `CLAUDE.md` in the repo root and commit it.
3. Fill in the `[TBD]` lines: commands once the repo has them, the data rule after Eric answers, the secrets approach after Q11.
4. Start Claude Code from the repo root. First prompt: "Read CLAUDE.md. Write the test plan for the first automation before any code." That enforces the test-first rule.
5. Check that Claude Code's approved model and API access match what Eric answers for Q8. The pattern in `CLAUDE.md` assumes a script may call Claude. If it cannot, the draft step becomes a Claude skill run by the business owner, and the checker stays the same.

## What I left out, and why

- **Recruiter, staffing agency, contract, timesheet, and time-off details.** Not for Nelnet systems, and irrelevant to the gate.
- **Names of staffing agency contacts.** Same reason. Only Eric and Dave remain.
- **The line about what happens if the gate is missed.** Eric knows it. It does not need to sit in a company tool.
- **Equipment and onboarding logistics.** Out of date by day one.
- **The practice kit.** Code stays out of Nelnet until rewritten there.
- **Interview prep and personal notes.** None are in this package.
- **Separate template files.** Merged into one `04-templates.md` to keep the upload count at five.

## Decision log entry

| 2026-10-26 | Nelnet Claude set up as a classic project: custom instructions plus 5 uploaded files; strict (sanitized-only) data rule until Eric confirms | Nelnet's Claude has classic Projects only; data rule not yet confirmed | Waiting for new-style projects | Daniel |
