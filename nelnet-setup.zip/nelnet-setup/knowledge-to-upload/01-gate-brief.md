# Gate Brief

**Last updated:** 2026-10-26

## Role
- Senior AI Enablement and Automation Consultant, Nelnet Shared Services
- Start: October 27, 2026 (day one is security training)
- Fully remote. Core hours 10 a.m. to 3 p.m. Central.
- Work: discovery, enablement, and hands-on delivery, ending in handoff to internal teams

## Stakeholders
| Name | Role | What they care about |
|---|---|---|
| Eric Ritchie | Direct manager, owns the gate | Two automations working after the first month; work shipped throughout, not saved for the end; systems that are safe, secure, and that his team understands and can support after handoff |
| Dave Newsome | Process team | [TBD: ask in week one] |

## Working with Eric
- Weekly 1:1, plus a weekly status report
- Blockers go to Eric on Teams right away, not held for the 1:1
- Disagree and commit: share views in the meeting, then everyone commits
- All work is done personally

## Teams served
Technical writing, IT training, and process. About 30 people, all under Eric. Each automation usually focuses on one team at a time.

## The gate
At week four: two automations deployed, in use by a team, with maintenance documentation someone else can follow. Automations do not need to be large. The point is proof of delivery.

**Clock start (confirmed by Eric, 2026-10-19):** the four weeks start once I have full access and have finished the required security training.

**Holiday risk:** Thanksgiving is November 26. If the clock starts around November 2, gate week four lands on Thanksgiving week. Target: both in use by November 20.

## Definitions to confirm with Eric
- "Deployed" means: [TBD: working solution the team uses, or formal production deployment? Who confirms acceptance?]
- "In use" means: [TBD: how many people, how often, measured how?]
- "Maintenance docs someone else can follow" means: [TBD: who is the named maintainer for each?]
- How the gate start date gets recorded: [TBD]

## Constraints
- No FedRAMP-boundary, CUI, or borrower data in scope. Work stays outside the boundary; Jira and Confluence are segmented out of it.
- Jira is moving from Data Center to cloud. Isolate the Jira read in one module so the migration changes one module.
- Claude Enterprise plan. Eric has had better results with Claude than Cowork.
- Claude Code Projects (redesigned) is not on Enterprise yet, no date. Do not plan around it.
- Claude Code Routines belong to one person's account and run without approval prompts. Not suitable for gate automations.
- Nelnet data and code stay in Nelnet tools. Practice code written before the start is rewritten inside Nelnet's GitLab, not copied in.

## History so far
- 2026-10-15 to 10-19: Planning and orientation call with Eric. 25 questions sent to him on 10-19 (tracked in file 08).
- 2026-10-19: Gate clock confirmed to start at full access plus security training. Target both automations in use by Nov 20 because Thanksgiving (Nov 26) likely lands in gate week four.
- Working pick for the two gate automations (Eric has not confirmed): monthly newsletter, and a NIST evidence completeness check (about 600 items in a 10-day window; completeness only, no model needed if rules suffice). Why: both are bounded, have a likely user, and Eric called them among the easier cases. Backup: tech-writer doc pipeline, which replaces NIST if the NIST window falls after gate week four.
- Pattern chosen: Python for deterministic steps, Claude at one bounded step with structured output that Python validates, a person reviews before anything is sent.
- 2026-10-26: Python 3.13 found in the company software portal (install requested, download pending when checked), so the build language is Python. Node.js is installed; .NET SDK, Antigravity, and Codex are also in the portal. Still to confirm with Eric: the owning team can maintain Python. Open: whether pip can reach an approved package source (Q29). Claude API approval still pending.
- Practice code was written before the start to prove the two patterns. It is not in Nelnet. The shape, tests, and evaluation cases carry over; the code is rewritten here in Python.

