# Automation Candidates

**Last updated:** 2026-10-19

**Status:** Eric has not picked the two yet. He is ranking his list by return on investment. My working pick: newsletter plus the NIST completeness slice, with the tech-writer pipeline as backup if the NIST window falls after gate week four.

## Evaluation rubric

Score each 1 (poor) to 5 (strong). A candidate that scores 1 on Data Access or Adoption cannot meet the gate, whatever else it scores.

| Criterion | 5 looks like | 1 looks like |
|---|---|---|
| **Value** | Saves many hours a month, visible to Eric | Saves little, nobody notices |
| **Effort** | Working v1 in days | Weeks of build |
| **Data access** | Access in hand or approved in week one | Blocked or unclear owner |
| **Risk** | Low error cost, easy human review | Errors reach outside parties |
| **Adoption** | A named person will use it weekly | No clear user |
| **Gate timing** | Can be in use before week four | Only runs outside the gate window |

**Gate timing note:** Thanksgiving is November 26 and likely falls in gate week four. A candidate must be in use by November 20 to score well on timing.

## Candidate 1: Monthly newsletter

**Known today:** someone on Dave's team manually reviews closed Jira tickets across two Jira Data Center instances, cross-references processes published in SharePoint, and writes a concise monthly summary of work done. Eric called it one of the easier use cases.

**Planned pattern:** Python pulls and groups tickets (Jira read isolated in one module for the cloud migration), Claude drafts the summary at one or two bounded steps, Python checks every cited ticket exists in the input, a person edits before sending.

| Criterion | Score | Notes |
|---|---|---|
| Value | | [TBD: hours per month today] |
| Effort | | |
| Data access | | Jira DC x2, SharePoint. [TBD: tokens or service account; Graph access] |
| Risk | | Internal audience, human edits before sending |
| Adoption | | [TBD: name of current writer] |
| Gate timing | | [TBD: when is the next issue due?] |

## Candidate 2: NIST evidence intake

**Known today:** evidence for each NIST control goes to government contractors and then business partners. Owners are known and contacted, they submit documentation, the team reviews it for completeness (timestamps and required fields), then sends it on. The crunch is volume: about 600 evidence items in a 10-day window. Eric called it the low-hanging fruit for Dave's team. All work stays outside the FedRAMP boundary.

**Planned pattern:** bounded slice first, a completeness check only. Likely rules in Python with no model at all; a model only if someone has to judge content.

| Criterion | Score | Notes |
|---|---|---|
| Value | | High volume in a short window |
| Effort | | Bounded slice: completeness check only |
| Data access | | [TBD: where submissions arrive and are tracked] |
| Risk | | Output reaches an outside contractor; human sign-off required |
| Adoption | | [TBD: intake owner name] |
| Gate timing | | [TBD: next window date. If after gate week four, "in use" by the gate may be impossible] |

## Candidate 3: Tech-writer doc pipeline

**Known today:** existing Claude skills scan Jira for development team work and draft documentation; writers then edit it. Eric wants it moved toward an agentic flow or an application, and called it one of the easiest quick wins. Deferred to months two and three unless it replaces NIST as the backup.

| Criterion | Score | Notes |
|---|---|---|
| Value | | |
| Effort | | Builds on something that already exists |
| Data access | | [TBD: where the skills live] |
| Risk | | Writers review every draft |
| Adoption | | Writers already use the current version |
| Gate timing | | Not tied to a calendar window |

## Pick two

| Rank | Candidate | Total | Why |
|---|---|---|---|
| 1 | [TBD: Eric's pick] | | |
| 2 | [TBD: Eric's pick] | | |
| Parked | | | |
