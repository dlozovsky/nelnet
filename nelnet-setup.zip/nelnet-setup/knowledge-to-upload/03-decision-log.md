# Decision Log

One line per decision. Add it the day it's made.

| Date | Decision | Why | Rejected alternatives | Owner |
|---|---|---|---|---|
| 2026-10-15 | Python for deterministic steps; Claude called only at bounded judgment steps with structured output that Python validates (draft, pending API access answer) | Testable, documentable, maintainable by someone else | Autonomous agent loop; pure no-code | Daniel |
| 2026-10-15 | Runtime: scheduled job if Claude API access is approved; otherwise a Claude skill run by the business owner (pending) | Both meet the gate; API access decides which | Cowork-style agent as core engine; Claude Code Projects; Claude Code Routines | Daniel |
| 2026-10-19 | Gate clock starts when full access is granted and security training is done | Eric on orientation call: onboarding shouldn't count | Clock starting October 27 | Eric |
| 2026-10-19 | Weekly status report and weekly 1:1; blockers raised on Teams immediately | Eric's stated preference | Holding blockers for the 1:1 | Eric / Daniel |
| 2026-10-19 | Target both automations in use by November 20 | Thanksgiving week likely falls in gate week four | Running gate testing through the holiday | Daniel |
| 2026-10-26 | SUPERSEDED same day by the Python 3.13 row below. Python looked unavailable: not installed and not seen in the portal. Node.js is installed. The .NET SDK, Antigravity, and Codex are in the portal | Found when checking the laptop and software portal | Requesting Python through an exception (costs time inside the gate) | Daniel |
| 2026-10-26 | SUPERSEDED: build language is C# or Node.js, Eric decides, owning team's language wins | Handoff only works if the team can support it | Choosing by my own preference | Daniel / Eric |
| 2026-10-26 | Python 3.13 found in the company software portal (install requested, download pending when checked); build language = Python | Matches the practice kit and the tests that carry over; check with Eric that the owning team can maintain Python is still open | C# or Node.js | Daniel |
| 2026-10-26 | Claude API approval still pending (Q8). Plan both paths: code calls Claude, or a Claude skill run by the business owner | Gate cannot wait on the answer | Waiting for approval before designing | Daniel |
| 2026-10-26 | Nelnet Claude set up as a classic project: custom instructions plus 5 uploaded files; strict (sanitized-only) data rule until Eric confirms | New-style projects not available; data rule unconfirmed | Waiting for new-style projects | Daniel |
