# Open Questions Tracker

Questions sent to Eric on 2026-10-19 (Teams note plus email). Section A is for Eric; B to E go to whoever owns each area. Record sanitized answers only: counts, dates, field names, rules, yes or no. No ticket contents, evidence items, or system details.

**Priority:** Critical = decides scope, acceptance, or feasibility. High = shapes the build. Secondary = refines build and handoff.

## A. Decisions for Eric

| # | Question | Priority | Answer | Answered by | Date |
|---|---|---|---|---|---|
| 1 | Which two automations go first? (Proposed: newsletter and NIST completeness slice) | Critical | | | |
| 2 | What does "deployed and in use" mean at week four, and who confirms acceptance? | Critical | | | |
| 3 | Who maintains each automation after handoff? | Critical | | | |
| 4 | How do we record the gate start date once access is in place? | Critical | | | |
| 5 | If access is ready by early November, is November 20 the right target for both in use? | Critical | | | |

## B. Platform (Eric or IT)

| # | Question | Priority | Answer | Answered by | Date |
|---|---|---|---|---|---|
| 6 | Where can Python automations run (app server, scheduled GitLab pipeline, container platform)? | Critical | | | |
| 7 | Is there a dev or test environment for validating automations? | High | | | |
| 8 | On Claude Enterprise, can a script call Claude through approved API access, or interface and skills only? Can skills be shared centrally? Is Claude Code on the web enabled, and are Routines allowed? | Critical | | | |
| 9 | Jira Data Center: personal access tokens or service accounts? Compatible versions across both instances? | Critical | | | |
| 10 | Is Microsoft Graph approved for reading SharePoint from a script, and who grants it? | Critical | | | |
| 11 | How are credentials and secrets managed for automations? | Critical | | | |
| 12 | When is the Jira cloud migration expected? | Secondary | | | |
| 27 | Build language | Critical | Closed 2026-10-26: Python 3.13 is in the company software portal (install requested). One line still worth sending Eric: can the team that will own each automation maintain Python? | Daniel | 2026-10-26 |
| 28 | Are Antigravity and Codex approved for Nelnet work, or only available in the portal? Same question for any other tool used to build. | High | | | |
| 29 | Can pip reach an approved package source or internal mirror (needed for anthropic, pyyaml, pytest)? If not, what is the approved way to bring in packages? | High | | | |
| 26 | Which AI tools are approved for Nelnet work, and are any outside tools allowed for non-Nelnet-data tasks? | High | | | |

## C. Newsletter (writer)

| # | Question | Priority | Answer | Answered by | Date |
|---|---|---|---|---|---|
| 13 | Who prepares it, hours per month, next issue due date? | High | | | |
| 14 | How are tickets selected (filter, projects, statuses, date range), and how many per issue? | High | | | |
| 15 | Which ticket fields are used? | High | | | |
| 16 | How are tickets matched to SharePoint process pages: explicit link or judgment? | High | | | |
| 17 | Delivery format, where published, who approves? | Secondary | | | |

## D. NIST evidence intake (intake owner)

| # | Question | Priority | Answer | Answered by | Date |
|---|---|---|---|---|---|
| 18 | When does the next 10-day window begin? | Critical | | | |
| 19 | What does a submission contain? | Secondary | | | |
| 20 | Where do submissions arrive, and how are they tracked? | Secondary | | | |
| 21 | Is there a written completeness checklist (fields, timestamps, formats)? | High | | | |
| 22 | Most common rejection reasons, and share failing first review? | High | | | |
| 23 | Who does first review, and what format goes to the contractor? | Secondary | | | |

## E. Tech-writer pipeline (backup)

| # | Question | Priority | Answer | Answered by | Date |
|---|---|---|---|---|---|
| 24 | Where do the current skills live, who runs them, how often? | Secondary | | | |
| 25 | What problems should moving to an agentic flow or app solve? | Secondary | | | |

## What each answer unlocks

- **8** decides the build pattern: scheduled Python job calling Claude, or a skill a person runs.
- **27** is closed: Python. **29** decides whether the practice kit dependencies can be installed at all.
- **14 and 15** define the shape of sample ticket data for the newsletter practice build.
- **21 and 22** become the rules config and evaluation set for the NIST checker.
- **18** decides whether NIST stays in the gate or the tech-writer pipeline replaces it.
