# Practice kit: the two gate patterns

Practice only. All data in `data/` and `evals/` is invented. Nothing here describes Nelnet systems.
Per the engagement rules, this code is **rewritten inside Nelnet's GitLab, not copied in**. What carries over is the shape, the tests, and the evaluation cases.

## The two patterns

**1. Collect, draft, check (newsletter)**

```
jira_source.py  ->  group.py  ->  draft.py  ->  check.py  ->  writer edits
(only module that    (plain Python:   (one Claude call,   (Python blocks the
 knows the source)   filter, group)   structured JSON)    draft if it fails)
```

- Claude is called once, with a JSON schema for the output. No agent loop, no framework.
- `check.py` blocks the draft if it cites a ticket that isn't in the input, has an item with no ticket cited, mentions an unknown ticket key, or uses a number not found in any ticket. Tickets left out show up as warnings for the writer.
- If scripts can't call the API (Q8), a Claude skill run by the writer replaces `draft.py`. The output goes through the same `check.py`.

**2. Rules config plus checker (NIST completeness)**

```
rules.yaml (owner can edit)  ->  check.py  ->  review list (CSV)  ->  person signs off
```

- No model. Every failure gets a reason, and a person reviews the list before anything leaves the team.

## Run it

```bash
pip install -r requirements.txt
python -m pytest                                                      # 14 unit tests
python -m newsletter.run --start 2026-09-01 --end 2026-09-30 --fake   # offline, no API key
python -m nist.run --window-start 2026-11-09 --window-end 2026-11-18
python -m evals.run_evals                                             # both evaluation sets
```

To try the real Claude step on a personal account with this fake data only: set `ANTHROPIC_API_KEY`, then drop `--fake`, or run `python -m evals.run_evals --live`.
Settings: `CLAUDE_MODEL` (default `claude-opus-5-5`) and `CLAUDE_FALLBACKS` (default `1`). Fallbacks re-run the request on another model if the first one declines; set it to `0` if Nelnet's access path doesn't support it.

## What the evaluation sets show

- **NIST: 14 of 14.** Each case targets one failure mode: a missing field, a bad date, stale evidence, the wrong file type, a duplicate, and so on. Rules have to be exact.
- **Newsletter with the fake drafter: 4 of 6.** This is expected. The fake copies ticket text word for word, so it fails N5 (an instruction hidden in a ticket) and N6 (a ticket that mentions an unknown key). Those are the traps the cases exist to catch. Run `--live` to see whether the real prompt handles them. The pass bar for the gate is 6 of 6 with zero invented facts.

## Practice exercises (about 1 hour each)

1. Run `--live` and read the draft. Change one line in `SYSTEM_PROMPT`, re-run the evals, and compare.
2. Add a newsletter case for a ticket with an empty summary. Decide whether it should pass or be blocked, then make the code agree.
3. Move a rule into `rules.yaml` (for example, a required field per evidence type) without touching `check.py` logic beyond reading it.
4. Write the maintenance guide (template 06) for this kit as if handing it to someone else. Every gap you find is a question for week one.

## Mapping to Nelnet, once access exists

| Practice piece | Replace with | Open question |
| --- | --- | --- |
| `FileSource` (or `JiraCloudSource`, see SETUP-JIRA-CLOUD.md) | `JiraDataCenterSource`, two instances | Q9, Q14, Q15 |
| `INCLUDED_RESOLUTIONS`, grouping by component | The writer's real selection and sections | Q14, Q17 |
| `ANTHROPIC_API_KEY` env var | Approved secrets store | Q8, Q11 |
| `rules.yaml` values | The intake owner's checklist | Q21, Q22 |
| `data/evidence_items.json` | Wherever submissions are tracked | Q20 |
| `evals/*.json` | Sanitized real cases, built inside Nelnet tools | |
| Local run | Scheduled job or skill | Q6, Q8 |
