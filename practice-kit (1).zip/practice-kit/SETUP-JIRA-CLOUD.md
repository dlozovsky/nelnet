# Set up a Jira Cloud practice site (about 45 minutes)

Do this on your personal computer with a personal email. Use made-up tickets only. Never use a Nelnet account, token, or data.

## 1. Create the free site (10 min)

1. Go to atlassian.com, open **Jira**, and choose the free option. Sign up with your personal email.
2. Pick a site name, for example `daniel-practice`. Your site address becomes `https://daniel-practice.atlassian.net`.
3. When asked for a template, pick **Kanban**. Name the project `Practice` with the key `PRAC`.

## 2. Create an API token (5 min)

1. Go to https://id.atlassian.com/manage-profile/security/api-tokens
2. Select **Create API token** (the plain one, not the one with scopes). Name it `practice-kit`.
3. Set the expiration to 30 days. Tokens can run from 1 to 365 days.
4. Select **Create**, then **Copy to clipboard**. You can't view it again later.

## 3. Put the settings in your environment (5 min)

Mac or Linux:

```bash
export JIRA_SITE="https://daniel-practice.atlassian.net"
export JIRA_EMAIL="you@personal-email.com"
export JIRA_API_TOKEN="paste-token-here"
export JIRA_PROJECT="PRAC"
```

Windows PowerShell:

```powershell
$env:JIRA_SITE="https://daniel-practice.atlassian.net"
$env:JIRA_EMAIL="you@personal-email.com"
$env:JIRA_API_TOKEN="paste-token-here"
$env:JIRA_PROJECT="PRAC"
```

The token goes in the environment only, never in a file you commit. This is the habit that carries over to Nelnet's secrets store.

## 4. Check the connection (2 min)

```bash
curl --user "$JIRA_EMAIL:$JIRA_API_TOKEN" "$JIRA_SITE/rest/api/3/myself"
```

You should see JSON with your display name. A 401 means the email or token is wrong.

## 5. Add practice tickets (10 min)

```bash
cd practice-kit
pip install -r requirements.txt
python scripts/seed_jira_cloud.py
```

This creates 10 made-up issues, including one eval trap. Then open the board and drag about half of them to **Done**.
If the script says the issue type is not valid, run it again with `JIRA_ISSUE_TYPE=Story` or whatever type your board lists.

## 6. Run the pipeline against your site (5 min)

```bash
python -m newsletter.run --start 2026-10-01 --end 2026-10-31 --fake --source cloud
```

- Use a date range that includes today, because the tickets were just closed.
- `--fake` skips Claude, so this tests the Jira read only. Drop `--fake` once you have `ANTHROPIC_API_KEY` set to see the full run.
- Open `out/draft.md` and check that every ticket you moved to Done is there and nothing else is.

## 7. If something breaks

| Symptom | Likely cause |
| --- | --- |
| 401 Unauthorized | Wrong email or token, or the token expired |
| 404 or 410 on `/rest/api/3/search/jql` | Atlassian changed the search API. Send me the error text |
| 0 tickets | Date range misses today, or nothing is in Done yet |
| 429 Too Many Requests | Rate limit. The code waits and retries up to 3 times |

## 8. What this teaches, and what differs at Nelnet

| Practiced here | At Nelnet (Data Center today) |
| --- | --- |
| Email plus API token, basic auth | Usually a personal access token or service account [TBD: Q9] |
| `/rest/api/3/search/jql`, paged by `nextPageToken` | Older search API, paged by `startAt` [TBD: confirm version, Q9] |
| One site | Two instances, so ticket keys can collide (the kit already checks) |
| Resolution sometimes unset in simple workflows | Depends on Nelnet's workflows [TBD: Q14] |

Only `JiraCloudSource` in `newsletter/jira_source.py` knows any of this. Everything after it is unchanged, which is the point of the exercise.

## 9. When you're done

Revoke the token at the same API tokens page.

Note: I confirmed the token steps and the `/rest/api/3/search/jql` endpoint against Atlassian's pages. The parameter and paging names in `JiraCloudSource` (`fields`, `maxResults`, `nextPageToken`, `isLast`) are from my knowledge and haven't been run against a live site yet. Your step 6 is that test.
