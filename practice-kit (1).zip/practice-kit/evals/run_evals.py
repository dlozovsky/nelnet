"""Runs both evaluation sets and prints pass rates.

    python -m evals.run_evals            # newsletter uses the offline fake drafter
    python -m evals.run_evals --live     # newsletter calls Claude

Re-run after any prompt, model, rules, or code change, and compare to the last run.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import date
from pathlib import Path

from newsletter.check import check_draft
from newsletter.draft import claude_draft, fake_draft
from newsletter.group import group_by_component
from newsletter.jira_source import Ticket
from nist.check import check_all, load_rules

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def to_ticket(raw: dict) -> Ticket:
    return Ticket(raw["key"], raw["instance"], raw["summary"], raw["resolution"],
                  date.fromisoformat(raw["resolved"]), raw.get("components", []), raw.get("labels", []))


def run_newsletter(live: bool) -> tuple[int, int]:
    cases = json.loads((HERE / "newsletter_cases.json").read_text())
    passed = 0
    for case in cases:
        tickets = [to_ticket(r) for r in case["tickets"]]
        groups = group_by_component(tickets)
        draft = claude_draft(groups) if live else fake_draft(groups)
        result = check_draft(draft, tickets)
        exp, problems = case["expect"], []
        if exp.get("check_passes") and not result.passed:
            problems += result.errors
        if exp.get("full_coverage") and result.warnings:
            problems += result.warnings
        if exp.get("empty") and draft.get("sections"):
            problems.append("Expected no sections for empty input")
        text = json.dumps(draft)
        problems += [f"Output contains {s!r}" for s in exp.get("must_not_contain", []) if s in text]
        ok = not problems
        passed += ok
        print(f"  {case['id']} {'PASS' if ok else 'FAIL'}  {case['failure_mode']}"
              + ("" if ok else f"  -> {'; '.join(problems)}"))
    return passed, len(cases)


def run_nist() -> tuple[int, int]:
    cases = json.loads((HERE / "nist_cases.json").read_text())
    rules = load_rules(ROOT / "nist/rules.yaml")
    results = check_all([c["item"] for c in cases], rules, date(2026, 11, 9), date(2026, 11, 18))
    passed = 0
    for case, res in zip(cases, results):
        ok = res.status == case["expected"]
        if ok and case.get("expected_reason"):
            ok = any(case["expected_reason"] in r for r in res.reasons)
        passed += ok
        print(f"  {res.item_id} {'PASS' if ok else 'FAIL'}  {case['failure_mode']}"
              + ("" if ok else f"  -> got {res.status}: {'; '.join(res.reasons)}"))
    return passed, len(cases)


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--live", action="store_true")
    args = p.parse_args()
    print(f"Newsletter ({'live Claude' if args.live else 'fake drafter'}):")
    n_pass, n_total = run_newsletter(args.live)
    print("NIST completeness:")
    k_pass, k_total = run_nist()
    print(f"\nNewsletter {n_pass}/{n_total}, NIST {k_pass}/{k_total}")
    # Pass thresholds from the test plan: NIST rules must be exact; newsletter allows no invented facts.
    return 0 if k_pass == k_total else 1


if __name__ == "__main__":
    sys.exit(main())
