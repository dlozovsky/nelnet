"""Validates a draft against its input. Runs on every draft, model or skill."""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from .jira_source import Ticket

KEY_PATTERN = re.compile(r"\b[A-Z][A-Z0-9]+-\d+\b")
NUMBER_PATTERN = re.compile(r"\d+(?:[.,]\d+)?")


@dataclass
class CheckResult:
    errors: list[str] = field(default_factory=list)    # block the draft
    warnings: list[str] = field(default_factory=list)  # writer reviews

    @property
    def passed(self) -> bool:
        return not self.errors


def check_draft(draft: dict, tickets: list[Ticket]) -> CheckResult:
    result = CheckResult()
    known = {t.key for t in tickets}
    known_numbers = {n for t in tickets for n in NUMBER_PATTERN.findall(t.summary)}
    cited: set[str] = set()

    for section in draft.get("sections", []):
        for item in section.get("items", []):
            keys = item.get("ticket_keys", [])
            if not keys:
                result.errors.append(f"Uncited item: {item.get('text', '')!r}")
            for key in keys:
                if key not in known:
                    result.errors.append(f"Cites a ticket not in the input: {key}")
                cited.add(key)
            # Keys written into the text must also be in the input.
            for key in KEY_PATTERN.findall(item.get("text", "")):
                if key not in known:
                    result.errors.append(f"Text mentions a ticket not in the input: {key}")
            # Numbers in the text must come from a ticket summary, not the model.
            for number in NUMBER_PATTERN.findall(KEY_PATTERN.sub("", item.get("text", ""))):
                if number not in known_numbers:
                    result.errors.append(f"Number not found in any ticket: {number}")

    for key in sorted(known - cited):
        result.warnings.append(f"Ticket not covered by any item: {key}")
    return result


def to_markdown(draft: dict) -> str:
    lines = []
    for section in draft.get("sections", []):
        lines.append(f"## {section['heading']}\n")
        for item in section["items"]:
            lines.append(f"- {item['text']} ({', '.join(item['ticket_keys'])})")
        lines.append("")
    return "\n".join(lines)
