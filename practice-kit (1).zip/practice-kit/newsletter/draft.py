"""The one bounded model step: grouped tickets in, structured draft out.

Claude only writes. Python validates the result in check.py before anyone sees it.
If script API access is not approved (Q8), this step is replaced by a Claude skill
the writer runs on the same input file, and check.py still validates the output.
"""
from __future__ import annotations

import json
import os

from .jira_source import Ticket

MODEL = os.environ.get("CLAUDE_MODEL", "claude-opus-5-5")
# Server-side refusal fallback. Turn off if Nelnet's access path does not support it.
USE_FALLBACKS = os.environ.get("CLAUDE_FALLBACKS", "1") == "1"

SYSTEM_PROMPT = """You draft a short internal monthly newsletter of completed work.
Rules:
- Use only the tickets provided. Do not add work, numbers, people, or dates that are not in them.
- Every item must cite the ticket keys it is based on, exactly as given.
- Group items under the section headings provided. Merge tickets that describe the same work.
- Plain language, one sentence per item, no hype.
- If no tickets are provided, return an empty sections list."""

DRAFT_SCHEMA = {
    "type": "object",
    "properties": {
        "sections": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "heading": {"type": "string"},
                    "items": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "text": {"type": "string"},
                                "ticket_keys": {"type": "array", "items": {"type": "string"}},
                            },
                            "required": ["text", "ticket_keys"],
                            "additionalProperties": False,
                        },
                    },
                },
                "required": ["heading", "items"],
                "additionalProperties": False,
            },
        }
    },
    "required": ["sections"],
    "additionalProperties": False,
}


class DraftError(RuntimeError):
    pass


def build_input(groups: dict[str, list[Ticket]]) -> str:
    payload = {
        heading: [{"key": t.key, "summary": t.summary, "labels": t.labels} for t in tickets]
        for heading, tickets in groups.items()
    }
    return json.dumps(payload, indent=2)


def claude_draft(groups: dict[str, list[Ticket]]) -> dict:
    import anthropic

    client = anthropic.Anthropic()
    kwargs = dict(
        model=MODEL,
        max_tokens=16000,
        system=SYSTEM_PROMPT,
        output_config={"effort": "medium", "format": {"type": "json_schema", "schema": DRAFT_SCHEMA}},
        messages=[{"role": "user", "content": "Tickets by section:\n" + build_input(groups)}],
    )
    if USE_FALLBACKS:
        response = client.beta.messages.create(
            betas=["server-side-fallback-2026-07-01"], fallbacks="default", **kwargs
        )
    else:
        response = client.messages.create(**kwargs)

    if response.stop_reason == "refusal":
        raise DraftError("Model declined the request; draft by hand this cycle")
    if response.stop_reason == "max_tokens":
        raise DraftError("Draft was cut off; raise max_tokens or split the input")
    text = next(b.text for b in response.content if b.type == "text")
    return json.loads(text)


def fake_draft(groups: dict[str, list[Ticket]]) -> dict:
    """Offline stand-in so the pipeline runs with no API key. One item per ticket."""
    return {
        "sections": [
            {"heading": heading, "items": [{"text": t.summary + ".", "ticket_keys": [t.key]} for t in tickets]}
            for heading, tickets in groups.items()
        ]
    }
