"""Deterministic selection and grouping. No model here."""
from __future__ import annotations

from collections import defaultdict

from .jira_source import Ticket

# [TBD: Q14, which resolutions count as "work done"]
INCLUDED_RESOLUTIONS = {"Done"}


def select(tickets: list[Ticket]) -> list[Ticket]:
    return [t for t in tickets if t.resolution in INCLUDED_RESOLUTIONS]


def find_key_collisions(tickets: list[Ticket]) -> list[str]:
    """Keys that appear in more than one Jira instance. Citations would be ambiguous."""
    seen: dict[str, set[str]] = defaultdict(set)
    for t in tickets:
        seen[t.key].add(t.instance)
    return sorted(k for k, instances in seen.items() if len(instances) > 1)


def group_by_component(tickets: list[Ticket]) -> dict[str, list[Ticket]]:
    groups: dict[str, list[Ticket]] = defaultdict(list)
    for t in sorted(tickets, key=lambda t: t.key):
        groups[t.components[0] if t.components else "Other"].append(t)
    return dict(sorted(groups.items()))
