"""Ticket source. The only module that knows where tickets come from.

The Jira cloud migration should change this file and nothing else.
Everything downstream works with the Ticket dataclass.
"""
from __future__ import annotations

import base64
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from datetime import date, timedelta
from pathlib import Path


@dataclass(frozen=True)
class Ticket:
    key: str
    instance: str
    summary: str
    resolution: str
    resolved: date
    components: list[str] = field(default_factory=list)
    labels: list[str] = field(default_factory=list)


class FileSource:
    """Reads fake tickets from JSON files. Used for practice and tests."""

    def __init__(self, paths: list[Path]):
        self.paths = paths

    def closed_tickets(self, start: date, end: date) -> list[Ticket]:
        tickets = []
        for path in self.paths:
            for raw in json.loads(Path(path).read_text()):
                t = Ticket(
                    key=raw["key"],
                    instance=raw["instance"],
                    summary=raw["summary"],
                    resolution=raw["resolution"],
                    resolved=date.fromisoformat(raw["resolved"]),
                    components=raw.get("components", []),
                    labels=raw.get("labels", []),
                )
                if start <= t.resolved <= end:
                    tickets.append(t)
        return tickets


class JiraCloudSource:
    """Reads closed tickets from a Jira Cloud site. Practice target for the real API.

    Settings come from environment variables, never from code:
      JIRA_SITE       https://your-site.atlassian.net
      JIRA_EMAIL      the Atlassian account email
      JIRA_API_TOKEN  token from id.atlassian.com, basic auth with the email
      JIRA_PROJECT    optional project key to limit the search
    """

    FIELDS = "summary,status,resolution,resolutiondate,statuscategorychangedate,components,labels"
    PAGE_SIZE = 50

    def __init__(self, instance: str = "CLOUD", opener=urllib.request.urlopen):
        self.site = os.environ["JIRA_SITE"].rstrip("/")
        creds = f"{os.environ['JIRA_EMAIL']}:{os.environ['JIRA_API_TOKEN']}".encode()
        self.auth = "Basic " + base64.b64encode(creds).decode()
        self.project = os.environ.get("JIRA_PROJECT")
        self.instance = instance
        self.opener = opener

    def jql(self, start: date, end: date) -> str:
        # Search on "updated" and filter on the resolved date in Python: a project whose
        # workflow never sets Resolution would otherwise return nothing.
        q = f'statusCategory = Done AND updated >= "{start}" AND updated < "{end + timedelta(days=1)}"'
        if self.project:
            q = f'project = "{self.project}" AND ' + q
        return q + " ORDER BY key"

    def _get(self, path: str, params: dict) -> dict:
        url = f"{self.site}{path}?{urllib.parse.urlencode(params)}"
        request = urllib.request.Request(url, headers={"Authorization": self.auth, "Accept": "application/json"})
        for attempt in range(4):
            try:
                with self.opener(request, timeout=30) as response:
                    return json.loads(response.read())
            except urllib.error.HTTPError as e:
                if e.code == 429 and attempt < 3:
                    time.sleep(int(e.headers.get("Retry-After", "5")))
                    continue
                raise
        raise RuntimeError("unreachable")

    def raw_issues(self, start: date, end: date):
        params = {"jql": self.jql(start, end), "fields": self.FIELDS, "maxResults": self.PAGE_SIZE}
        while True:
            page = self._get("/rest/api/3/search/jql", params)
            yield from page.get("issues", [])
            token = page.get("nextPageToken")
            if not token or page.get("isLast"):
                return
            params["nextPageToken"] = token

    def to_ticket(self, raw: dict) -> Ticket | None:
        f = raw["fields"]
        resolved = f.get("resolutiondate") or f.get("statuscategorychangedate")
        if not resolved:
            return None
        resolution = (f.get("resolution") or {}).get("name") or (f.get("status") or {}).get("name", "")
        return Ticket(
            key=raw["key"],
            instance=self.instance,
            summary=f.get("summary", ""),
            resolution=resolution,
            resolved=date.fromisoformat(resolved[:10]),
            components=[c["name"] for c in f.get("components") or []],
            labels=f.get("labels") or [],
        )

    def closed_tickets(self, start: date, end: date) -> list[Ticket]:
        tickets = (self.to_ticket(raw) for raw in self.raw_issues(start, end))
        return [t for t in tickets if t and start <= t.resolved <= end]


class JiraDataCenterSource:
    """Placeholder for the real read, written inside Nelnet's GitLab.

    [TBD: Q9, token or service account] [TBD: Q14, filter or JQL used today]
    [TBD: Q15, which fields] Credentials come from the approved secrets
    store (Q11), never from code or config files.
    """

    def closed_tickets(self, start: date, end: date) -> list[Ticket]:
        raise NotImplementedError("Build inside Nelnet once Jira access is granted")
