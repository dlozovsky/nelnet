"""Newsletter pipeline: collect, group, draft, check, write for the human editor.

Usage:
    python -m newsletter.run --start 2026-09-01 --end 2026-09-30 --fake
    python -m newsletter.run --start 2026-09-01 --end 2026-09-30   # calls Claude
    python -m newsletter.run --start 2026-10-01 --end 2026-10-31 --fake --source cloud
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import date
from pathlib import Path

from .check import check_draft, to_markdown
from .draft import claude_draft, fake_draft
from .group import find_key_collisions, group_by_component, select
from .jira_source import FileSource, JiraCloudSource

ROOT = Path(__file__).resolve().parent.parent


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--start", type=date.fromisoformat, required=True)
    p.add_argument("--end", type=date.fromisoformat, required=True)
    p.add_argument("--fake", action="store_true", help="skip the Claude call")
    p.add_argument("--source", choices=["file", "cloud"], default="file", help="fake files or a Jira Cloud site")
    p.add_argument("--out", type=Path, default=ROOT / "out")
    args = p.parse_args(argv)

    if args.source == "cloud":
        source = JiraCloudSource()
    else:
        source = FileSource([ROOT / "data/tickets_instance_a.json", ROOT / "data/tickets_instance_b.json"])
    tickets = select(source.closed_tickets(args.start, args.end))
    collisions = find_key_collisions(tickets)
    if collisions:
        print(f"Stop: same key in two Jira instances: {collisions}", file=sys.stderr)
        return 2

    groups = group_by_component(tickets)
    draft = fake_draft(groups) if args.fake else claude_draft(groups)
    result = check_draft(draft, tickets)

    args.out.mkdir(exist_ok=True)
    (args.out / "draft.json").write_text(json.dumps(draft, indent=2))
    (args.out / "check.json").write_text(json.dumps({"errors": result.errors, "warnings": result.warnings}, indent=2))
    print(f"{len(tickets)} tickets, {len(groups)} sections, "
          f"{len(result.errors)} errors, {len(result.warnings)} warnings")
    if not result.passed:
        print("Draft blocked. See out/check.json", file=sys.stderr)
        return 1
    (args.out / "draft.md").write_text(to_markdown(draft))
    print(f"Draft ready for the writer: {args.out / 'draft.md'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
