"""Completeness check for evidence items. Rules only, no model.

Output is a pass or fail per item with every reason, for a person to review
before anything goes to a contractor.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, timedelta
from pathlib import Path

import yaml


@dataclass
class ItemResult:
    item_id: str
    reasons: list[str] = field(default_factory=list)

    @property
    def status(self) -> str:
        return "PASS" if not self.reasons else "FAIL"


def load_rules(path: Path) -> dict:
    return yaml.safe_load(Path(path).read_text())


def _parse_date(value) -> date | None:
    try:
        return date.fromisoformat(str(value))
    except ValueError:
        return None


def check_item(item: dict, rules: dict, window_start: date, window_end: date) -> ItemResult:
    result = ItemResult(item_id=str(item.get("item_id", "?")))
    r = result.reasons

    for name in rules["required_fields"]:
        if not str(item.get(name) or "").strip():
            r.append(f"Missing {name}")

    dates = {}
    for name in rules["date_fields"]:
        if item.get(name):
            parsed = _parse_date(item[name])
            if parsed is None:
                r.append(f"{name} is not a valid date: {item[name]!r}")
            dates[name] = parsed

    evidence_date, submitted_at = dates.get("evidence_date"), dates.get("submitted_at")
    if evidence_date:
        oldest = window_start - timedelta(days=rules["max_evidence_age_days"])
        if evidence_date < oldest:
            r.append(f"evidence_date older than {rules['max_evidence_age_days']} days before the window")
        if evidence_date > window_end:
            r.append("evidence_date is in the future")
    if submitted_at and not (window_start <= submitted_at <= window_end):
        r.append("submitted_at outside the intake window")
    if evidence_date and submitted_at and evidence_date > submitted_at:
        r.append("evidence_date is after submitted_at")

    control_id = item.get("control_id")
    if control_id and not re.match(rules["control_id_pattern"], control_id):
        r.append(f"control_id format not recognized: {control_id!r}")

    file_name = item.get("file_name")
    if file_name and Path(file_name).suffix.lower() not in rules["allowed_file_types"]:
        r.append(f"file type not allowed: {Path(file_name).suffix or 'none'}")

    description = item.get("description")
    if description and description.strip() and len(description.strip()) < rules["min_description_chars"]:
        r.append("description too short to review")
    return result


def check_all(items: list[dict], rules: dict, window_start: date, window_end: date) -> list[ItemResult]:
    results = [check_item(i, rules, window_start, window_end) for i in items]
    seen: dict[str, int] = {}
    for item, res in zip(items, results):
        key = f"{item.get('control_id')}|{item.get('file_name')}"
        if key in seen:
            res.reasons.append(f"Possible duplicate of item {seen[key]}")
        else:
            seen[key] = item.get("item_id")
    return results
