"""Runs the completeness check and writes a review list.

Usage:
    python -m nist.run --window-start 2026-11-09 --window-end 2026-11-18
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from datetime import date
from pathlib import Path

from .check import check_all, load_rules

ROOT = Path(__file__).resolve().parent.parent


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--window-start", type=date.fromisoformat, required=True)
    p.add_argument("--window-end", type=date.fromisoformat, required=True)
    p.add_argument("--items", type=Path, default=ROOT / "data/evidence_items.json")
    p.add_argument("--rules", type=Path, default=ROOT / "nist/rules.yaml")
    p.add_argument("--out", type=Path, default=ROOT / "out")
    args = p.parse_args(argv)

    items = json.loads(args.items.read_text())
    results = check_all(items, load_rules(args.rules), args.window_start, args.window_end)

    args.out.mkdir(exist_ok=True)
    out_file = args.out / "completeness_review.csv"
    with out_file.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["item_id", "status", "reasons"])
        for r in results:
            w.writerow([r.item_id, r.status, "; ".join(r.reasons)])

    failed = sum(r.status == "FAIL" for r in results)
    print(f"{len(results)} items, {len(results) - failed} pass, {failed} fail. Review list: {out_file}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
