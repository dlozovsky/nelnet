"""JiraCloudSource against canned responses. No network."""
import io
import json
from datetime import date

import pytest

from newsletter.jira_source import JiraCloudSource


def issue(key, resolved="2026-10-05T10:00:00.000+0000", resolution="Done", summary="Fix login"):
    return {"key": key, "fields": {
        "summary": summary, "status": {"name": "Done"},
        "resolution": {"name": resolution} if resolution else None,
        "resolutiondate": resolved if resolution else None,
        "statuscategorychangedate": resolved,
        "components": [{"name": "Intake"}], "labels": ["internal"]}}


class FakeOpener:
    def __init__(self, pages):
        self.pages, self.urls = list(pages), []

    def __call__(self, request, timeout):
        self.urls.append(request.full_url)
        return io.BytesIO(json.dumps(self.pages.pop(0)).encode())


@pytest.fixture
def env(monkeypatch):
    monkeypatch.setenv("JIRA_SITE", "https://example.atlassian.net")
    monkeypatch.setenv("JIRA_EMAIL", "me@example.com")
    monkeypatch.setenv("JIRA_API_TOKEN", "not-a-real-token")


def test_pages_until_no_token(env):
    opener = FakeOpener([
        {"issues": [issue("P-1")], "nextPageToken": "abc", "isLast": False},
        {"issues": [issue("P-2")], "isLast": True},
    ])
    tickets = JiraCloudSource(opener=opener).closed_tickets(date(2026, 10, 1), date(2026, 10, 31))
    assert [t.key for t in tickets] == ["P-1", "P-2"]
    assert "nextPageToken=abc" in opener.urls[1]


def test_maps_fields_and_falls_back_when_resolution_unset(env):
    opener = FakeOpener([{"issues": [issue("P-3", resolution=None)], "isLast": True}])
    [t] = JiraCloudSource(opener=opener).closed_tickets(date(2026, 10, 1), date(2026, 10, 31))
    assert (t.resolution, t.resolved, t.components) == ("Done", date(2026, 10, 5), ["Intake"])


def test_filters_out_tickets_resolved_outside_range(env):
    opener = FakeOpener([{"issues": [issue("P-4", resolved="2026-09-20T10:00:00.000+0000")], "isLast": True}])
    assert JiraCloudSource(opener=opener).closed_tickets(date(2026, 10, 1), date(2026, 10, 31)) == []
