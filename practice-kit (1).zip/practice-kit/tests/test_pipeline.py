from datetime import date
from pathlib import Path

from newsletter.check import check_draft
from newsletter.group import find_key_collisions, select
from newsletter.jira_source import FileSource, Ticket
from nist.check import check_item, load_rules

ROOT = Path(__file__).resolve().parent.parent


def ticket(key, summary="Add delegate approver option", instance="A", resolution="Done"):
    return Ticket(key, instance, summary, resolution, date(2026, 9, 15), ["Approvals"], [])


def draft(*items):
    return {"sections": [{"heading": "Approvals", "items": [{"text": t, "ticket_keys": k} for t, k in items]}]}


# Newsletter

def test_file_source_filters_by_date():
    src = FileSource([ROOT / "data/tickets_instance_a.json"])
    tickets = src.closed_tickets(date(2026, 9, 1), date(2026, 9, 10))
    assert tickets and all(date(2026, 9, 1) <= t.resolved <= date(2026, 9, 10) for t in tickets)


def test_select_keeps_done_only():
    assert [t.key for t in select([ticket("P-1"), ticket("P-2", resolution="Won't Do")])] == ["P-1"]


def test_key_collision_across_instances():
    assert find_key_collisions([ticket("P-1", instance="A"), ticket("P-1", instance="B")]) == ["P-1"]


def test_clean_draft_passes():
    assert check_draft(draft(("Added a delegate approver option.", ["P-1"])), [ticket("P-1")]).passed


def test_invented_ticket_blocked():
    result = check_draft(draft(("Something.", ["P-404"])), [ticket("P-1")])
    assert not result.passed and "P-404" in result.errors[0]


def test_uncited_item_blocked():
    assert not check_draft(draft(("Something.", [])), [ticket("P-1")]).passed


def test_invented_number_blocked():
    result = check_draft(draft(("Saved 40 hours.", ["P-1"])), [ticket("P-1")])
    assert any("40" in e for e in result.errors)


def test_number_from_ticket_allowed():
    t = ticket("P-1", summary="Reduce approval steps from 5 to 3")
    assert check_draft(draft(("Approval steps cut from 5 to 3.", ["P-1"])), [t]).passed


def test_uncovered_ticket_is_warning_not_error():
    result = check_draft(draft(("Added a delegate approver option.", ["P-1"])), [ticket("P-1"), ticket("P-2")])
    assert result.passed and result.warnings == ["Ticket not covered by any item: P-2"]


# NIST

RULES = load_rules(ROOT / "nist/rules.yaml")
GOOD = dict(item_id="E1", control_id="AC-2", owner="Owner A", evidence_type="Screenshot",
            description="Quarterly access review sign-off", evidence_date="2026-10-15",
            submitted_at="2026-11-10", file_name="ac2.pdf")


def check(**changes):
    return check_item({**GOOD, **changes}, RULES, date(2026, 11, 9), date(2026, 11, 18))


def test_complete_item_passes():
    assert check().status == "PASS"


def test_every_problem_is_reported():
    result = check(owner="", file_name="ac2.docx", control_id="AC2")
    assert result.status == "FAIL" and len(result.reasons) == 3
